const Footer = () =>{
  return (
        <div className="footer h-[100px] bg-[#1A719C] flex justify-center place-items-center  text-[16px] text-white">
          Integrated of Banda Aceh, Sabang, and Lhokseumawe Information System
        </div>
  )
}

export default Footer;