// src/AuthContext.js
import { createContext, useContext, useState } from "react";

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    // Cek token di localStorage
    return localStorage.getItem("token") !== null;
  });

  const [isAuthenticatedAdmin, setIsAuthenticatedAdmin] = useState(() => {
    // Cek token di localStorage
    return localStorage.getItem("tokenadmin") !== null;
  });

  return (
    <AuthContext.Provider value={{ isAuthenticated, isAuthenticatedAdmin }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  return useContext(AuthContext);
};
