// src/App.js
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import "./App.css";
import { AuthProvider, useAuth } from "./auth/AuthContext";
import {
  ProtectedRoute,
  ProtectedRouteAdmin,
} from "./components/ProtectedRoute";
import Arv from "./components/Arv";
import Dept from "./components/Dept";
import SignOn from "./components/SignOn";
import SignOff from "./components/SignOff";
import Home from "./components/Home";
import Dashboard from "./components/Dashboard";
import LoginUser from "./components/LoginUser";
import LoginAdmin from "./components/LoginAdmin";
import Register from "./components/Register";
import ReqReg from "./components/ReqReg";
import AdmCruSignOff from "./components/AdmCruSignOff";
import AdmCruSignOn from "./components/AdmCruSignOn";
import AdmDataKeb from "./components/AdmDataKeb";
import AdmDataKed from "./components/AdmDataKed";
import NotificationModal from "./components/NotificationModal";

function App() {
  document.title = "MARS";
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
    
          <Route path="/" element={<Home />} />
          <Route
            path="/arrival"
            element={<ProtectedRoute element={<Arv />} />}
          />
          <Route
            path="/departure"
            element={<ProtectedRoute element={<Dept />} />}
          />
          <Route
            path="/sign-on"
            element={<ProtectedRoute element={<SignOn />} />}
          />
          <Route
            path="/sign-off"
            element={<ProtectedRoute element={<SignOff />} />}
          />
          <Route
            path="/dashboard"
            element={<ProtectedRoute element={<Dashboard />} />}
          />
          <Route path="/loginuser" element={<LoginUser />} />
          <Route path="/loginadmin" element={<LoginAdmin />} />
          <Route path="/register" element={<Register />} />
          <Route 
            path="/request-register" 
            element={<ProtectedRouteAdmin element={<ReqReg/>} />} />
          <Route
            path="/admin-cru-sign-off"
            element={<ProtectedRouteAdmin element={<AdmCruSignOff />} />}
          />
          <Route
            path="/admin-cru-sign-on"
            element={<ProtectedRouteAdmin element={<AdmCruSignOn />} />}
          />
          <Route
            path="/admin-data-keb"
            element={<ProtectedRouteAdmin element={<AdmDataKeb />} />}
          />
          <Route
            path="/admin-data-ked"
            element={<ProtectedRouteAdmin element={<AdmDataKed />} />}
          />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
